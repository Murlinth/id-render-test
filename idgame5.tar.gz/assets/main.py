import asyncio
import pygame

pygame.init()
screen = pygame.display.set_mode((480, 800))
pygame.display.set_caption("GlobalTest")

running = True
counter = 0

async def main():
    global running, counter
    while running:
        counter += 1
        screen.fill((0, 200, 0))
        pygame.display.flip()
        await asyncio.sleep(0)
        if counter > 1000000:
            running = False

asyncio.run(main())
