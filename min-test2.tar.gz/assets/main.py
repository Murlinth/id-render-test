import asyncio
import json
import os
import pygame

pygame.init()
pygame.mixer.init()
pygame.key.stop_text_input()
pygame.key.start_text_input()
screen = pygame.display.set_mode((480, 800))
pygame.display.set_caption("Test2 OK")

async def main():
    while True:
        screen.fill((30, 30, 200))
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
