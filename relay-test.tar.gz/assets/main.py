# Relay test for Inverse Dimensions V2 (two-phone multiplayer).
# Proves, from inside a pygbag browser build, that the game can:
#  1) POST a message to a free relay (ntfy.sh topic) via the JS bridge
#  2) GET / poll that topic and see messages sent by ANOTHER tab
# Two tabs open the same page: tap SEND TEST in one, the other should
# show the token in its received list within a few seconds.
import asyncio, json, random, sys
import pygame
from pathlib import Path

WEB = sys.platform == "emscripten"
if WEB:
    import platform
    from platform import window

TOPIC = "idim-relay-test-7f3k9"
NTFY = "https://ntfy.sh/" + TOPIC
MY_ID = str(random.randint(1000, 9999))

pygame.init()
screen = pygame.display.set_mode((480, 800))
pygame.display.set_caption("Relay Test")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 28)
small = pygame.font.Font(None, 22)

send_rect = pygame.Rect(60, 640, 360, 56)
send_status = "not sent yet"
poll_status = "polling..."
poll_via = "-"
last_error = ""
received = []  # list of (sender, token)
seen = set()
running = True

async def js_fetch(url, method="GET", body=None):
    # JS fetch via the pygbag bridge; returns response text.
    body_js = "null" if body is None else json.dumps(body)
    js = ("fetch(%s, {method: %s, body: %s}).then(r => r.text())"
          % (json.dumps(url), json.dumps(method), body_js))
    return await window.eval(js)

async def do_send():
    global send_status, last_error
    token = str(random.randint(1000, 9999))
    payload = json.dumps({"from": MY_ID, "token": token})
    try:
        if WEB:
            await js_fetch(NTFY, "POST", payload)
            send_status = "sent token " + token
        else:
            send_status = "browser only"
    except Exception as e:
        send_status = "SEND FAILED"
        last_error = "send: " + str(e)[:120]

async def do_poll_once():
    global poll_status, poll_via, last_error
    url = NTFY + "/json?since=all&poll=1"
    text = None
    try:
        if WEB:
            async with platform.fopen(Path(url), "r") as f:
                text = f.read()
            poll_via = "fopen"
    except Exception:
        try:
            text = await js_fetch(url, "GET")
            poll_via = "window.eval"
        except Exception as e2:
            poll_status = "POLL FAILED"
            last_error = "poll: " + str(e2)[:120]
            return
    poll_status = "poll ok"
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        try:
            data = json.loads(obj.get("message", ""))
        except Exception:
            continue
        key = (data.get("from"), data.get("token"))
        if key not in seen and data.get("token"):
            seen.add(key)
            received.append(key)

async def poll_loop():
    while running:
        await do_poll_once()
        await asyncio.sleep(2)

def draw_text(surf, text, y, fnt, color=(255, 255, 255)):
    surf.blit(fnt.render(text, True, color), (24, y))

async def main():
    global running
    asyncio.create_task(poll_loop())
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if send_rect.collidepoint(event.pos):
                    await do_send()
        screen.fill((20, 20, 40))
        draw_text(screen, "RELAY TEST", 30, font, (255, 215, 0))
        draw_text(screen, "My ID: " + MY_ID, 70, small)
        draw_text(screen, "Topic: " + TOPIC, 95, small)
        draw_text(screen, "SEND: " + send_status, 140, small)
        draw_text(screen, "POLL: " + poll_status + " via " + poll_via, 165, small)
        if last_error:
            draw_text(screen, last_error, 190, small, (255, 120, 120))
        draw_text(screen, "Received:", 230, font)
        y = 265
        for sender, token in received[-8:]:
            tag = "other tab" if sender != MY_ID else "me"
            draw_text(screen, "%s: %s (%s)" % (sender, token, tag), y, small)
            y += 26
        pygame.draw.rect(screen, (52, 199, 89), send_rect, border_radius=12)
        lbl = font.render("SEND TEST", True, (255, 255, 255))
        screen.blit(lbl, lbl.get_rect(center=send_rect.center))
        pygame.display.update()
        clock.tick(30)
        await asyncio.sleep(0)

asyncio.run(main())
