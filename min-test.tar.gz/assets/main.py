import asyncio
import pygame

pygame.init()
screen = pygame.display.set_mode((480, 800))
pygame.display.set_caption("Test OK")

async def main():
    while True:
        screen.fill((200, 30, 30))
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
